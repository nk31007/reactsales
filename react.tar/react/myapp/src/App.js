import { useState } from 'react';
import './App.css';
// import Sidebar from './components/Sidebar';
import UserData from './components/UserData';
import UserInput from './UserInput';

function App() {
  
  return (
    <div className="App">
      <center>
        <UserInput />
        <UserData/>
        </center>
    </div>
  );
}

export default App;
