import { Icon } from "@mui/material";
import { Button } from "bootstrap";
import React, { useState } from "react";

const UserInput = () => {
    const [data, setData] = useState({ 
        name: '',
        userName: ''
    })
    
const handleChange = (e)=>{
    setData({...data, [e.target.name]: e.target.value});
    console.log("data:", data)
}
const submitHandler = (e) => {
    e.preventDefault();
    fetch('https://testapi-7d7f3-default-rtdb.firebaseio.com/data.json', {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'Content-Type' : 'application/json'
        }
    }).then(res=>alert("Data Posted Successfully...")).catch(err=>console.log(`error is - ${err}`))

}
  return (
    <>
    <form onSubmit={submitHandler}>
        <label>Name:</label> 
        <input type='text' name="name"  onChange={handleChange}/> <br/>
        <label>userName:</label>
        <input type='text' name="userName"   onChange={handleChange}/>   <br/>
        <input type='submit' value='adduser'/> 
        
    </form>
    </>
  )
}

export default UserInput