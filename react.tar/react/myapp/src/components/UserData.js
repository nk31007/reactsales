import React from 'react'
import axios from 'axios'
import { useEffect, useState } from 'react'
import '../App.css'
function UserData() {
   const [userInfo, setuserInfo]=useState([])
    useEffect(()=>{
        axios.get('https://jsonplaceholder.typicode.com/users')
        .then((response)=>{
            setuserInfo(response.data)
    })
    },[])
  return (
    <>
    <table>
        <thead>
            {/* <tr> */}
                <th>
                    NAME
                </th>
                <th>
                    USERNAME
                </th>
            {/* </tr> */}
        </thead>
        <tbody>
    {userInfo.map((user,index) =>  
    <tr key={index}>
        <td>{user.name}</td>
        <td>{user.username}</td>
    </tr>
        
    )}
    </tbody>
    </table>
    </>
  )
}

export default UserData

