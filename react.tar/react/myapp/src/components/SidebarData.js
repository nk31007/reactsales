import React from 'react'

// function SidebarData() {
//   return (
//     <div className='SidebarData'></div>
//   )
// }

// export default SidebarData

export const SidebarData = [
    {
    title: "Home",
    icon: <Icon />,
    link: "/home"
},
]